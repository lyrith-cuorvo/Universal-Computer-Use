"""Real capture latency measurements, never synthetic E2E success."""
from __future__ import annotations

import statistics
import time

from .errors import U2CError


def percentile(values, p):
    if not values:
        return None
    points = sorted(values)
    position = (len(points)-1) * p
    left = int(position)
    return points[left] + (points[min(left+1, len(points)-1)]-points[left]) * (position-left)


def smoke(runtime, iterations=10, *, region=None, mode="safe"):
    if not isinstance(iterations, int) or not 1 <= iterations <= 100:
        raise U2CError("INVALID_REQUEST", "iterations must be between 1 and 100")
    started = time.perf_counter()
    times = []
    failures = []
    sid = None
    for index in range(iterations):
        at = time.perf_counter()
        try:
            observed = runtime.observe(sid, region=region, mode=mode)
            sid = observed["session_id"]
            times.append((time.perf_counter()-at)*1000)
        except U2CError as exc:
            failures.append({"iteration": index+1, "error": exc.as_dict()})
            # A missing permission is not repaired by repeated attempts.
            break
    return {
        "status": "PARTIAL" if times else "FAIL",
        "suite": "smoke", "kind": "real_screen_capture_only",
        "mode": mode,
        "full_visual_e2e": False, "session_id": sid,
        "iterations_requested": iterations, "iterations_completed": len(times),
        "failures": failures, "blocked_iterations": iterations-len(times)-len(failures),
        "screenshots": len(times), "actions": 0, "model_turns": 0,
        "human_interventions": 0,
        "latency_ms": {"p50": percentile(times, .5), "p95": percentile(times, .95),
                       "mean": statistics.mean(times) if times else None},
        "total_ms": round((time.perf_counter()-started)*1000, 3),
        "note": "Capture diagnostics do not establish model vision, keyboard, mouse, or Notepad success.",
    }
