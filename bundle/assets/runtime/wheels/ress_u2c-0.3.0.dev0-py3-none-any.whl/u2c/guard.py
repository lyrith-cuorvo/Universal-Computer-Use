"""Explicit risk declarations and bounded one-use approval tokens.

The guard cannot infer the meaning of every GUI click. The observing agent must
classify the user's intended operation; a human must approve sensitive work.
This trusted local CLI is not a security boundary against a malicious process
running as the same user, which could already issue native input directly.
"""
from __future__ import annotations

import hashlib
import json

from .errors import U2CError
from .protocol import RISKS


def request_digest(request):
    value = {key: value for key, value in request.items() if key != "approval_token"}
    serialized = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _shortcut_risks(action):
    kind = action.get("type")
    keys = set(action.get("keys", ())) if kind == "hotkey" else {action.get("key")} if kind == "key" else set()
    if keys in ({"win", "i"}, {"ctrl", "alt", "delete"}):
        return {"system_settings", "irreversible"}
    if "delete" in keys:
        return {"delete_files", "irreversible"}
    if keys in ({"win", "r"}, {"win", "x"}, {"ctrl", "shift", "escape"}):
        # Launching a command surface requires intent and human review. Typing
        # into an already-open terminal also requires the agent's declaration.
        return {"install_program", "system_settings", "irreversible"}
    if keys in ({"ctrl", "enter"}, {"alt", "s"}):
        return {"send_message", "submit_form", "irreversible"}
    if keys == {"alt", "f4"}:
        return {"irreversible"}
    return set()


class Guard:
    def __init__(self, store):
        self.store = store

    def check(self, request):
        risk = request.get("risk", "none")
        if type(risk) is not str or risk not in RISKS:
            raise U2CError("INVALID_REQUEST", "Unsupported risk classification")
        for action in request["actions"]:
            required = _shortcut_risks(action)
            if required and risk not in required:
                raise U2CError("APPROVAL_REQUIRED", "This shortcut requires a matching explicit risk classification and human approval", allowed_risks=sorted(required))
        if risk != "none":
            token = request.get("approval_token")
            if not token:
                raise U2CError("APPROVAL_REQUIRED", "Sensitive operations require explicit, request-bound human approval", risk=risk)
            self.store.consume_approval(request["session_id"], token, request_digest(request))
        elif request.get("approval_token"):
            # A token must never silently weaken or change a risk declaration.
            raise U2CError("INVALID_REQUEST", "approval_token is only valid with a sensitive risk classification")
