"""Strict, bounded validation for the screenshot-bound UAP JSON protocol."""
from __future__ import annotations

import math
import re
import uuid

from .errors import U2CError

PROTOCOL = "u2c.action.v0"
RISKS = frozenset({"none", "delete_files", "install_program", "submit_form", "send_message", "payment", "system_settings", "irreversible"})
KEYS = frozenset("abcdefghijklmnopqrstuvwxyz0123456789") | frozenset(f"f{i}" for i in range(1, 25)) | frozenset({"ctrl", "shift", "alt", "win", "enter", "tab", "escape", "space", "backspace", "delete", "insert", "home", "end", "pageup", "pagedown", "left", "right", "up", "down", "capslock", "numlock", "scrolllock", "printscreen", "pause"})
KEY_ALIASES = {"esc": "escape", "return": "enter", "control": "ctrl", "windows": "win"}


def _invalid(message, **details):
    raise U2CError("INVALID_REQUEST", message, **details)


def validate_session_id(value):
    if type(value) is not str:
        _invalid("session_id must be a UUID string")
    try:
        parsed = uuid.UUID(value)
    except (ValueError, AttributeError):
        _invalid("session_id must be a UUID string")
    if str(parsed) != value:
        _invalid("session_id must be a canonical lower-case UUID string")
    return value


def validate_frame_id(value):
    if type(value) is not str or not re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", value):
        _invalid("frame_id must contain 1-128 letters, numbers, underscores, dots or hyphens")
    return value


def _fields(data, required, optional=()):
    if type(data) is not dict:
        _invalid("Expected a JSON object")
    unknown = set(data) - set(required) - set(optional)
    missing = set(required) - set(data)
    if unknown:
        _invalid("Unknown fields", fields=sorted(map(str, unknown)))
    if missing:
        _invalid("Missing fields", fields=sorted(missing))


def _number(value, minimum, maximum, field):
    if type(value) not in (int, float) or not minimum <= value <= maximum or not math.isfinite(value):
        _invalid(f"{field} must be a finite number in [{minimum}, {maximum}]")
    return value


def action_limit(mode="safe", max_actions=None):
    if mode not in ("safe", "fast"):
        _invalid("mode must be safe or fast")
    if max_actions is None:
        return 4 if mode == "safe" else 16
    if type(max_actions) is not int or not 1 <= max_actions <= 64:
        _invalid("max_actions must be an integer in [1, 64]")
    return max_actions


def _coordinate(value, field):
    if type(value) is not int or not 0 <= value <= 1000:
        raise U2CError("OUT_OF_BOUNDS", f"{field} must be an integer in [0, 1000]")


def _key(value):
    if type(value) is not str:
        _invalid("key must be a supported key name")
    value = KEY_ALIASES.get(value.lower(), value.lower())
    if value not in KEYS:
        _invalid("Unsupported key name", key=value)
    return value


def _action(data):
    if type(data) is not dict or type(data.get("type")) is not str:
        _invalid("Each action must be an object with a string type")
    kind = data["type"]
    schemas = {
        "click": ({"type", "x", "y"}, {"button"}),
        "double_click": ({"type", "x", "y"}, {"button"}),
        "move": ({"type", "x", "y"}, {"duration"}),
        "drag": ({"type", "x", "y", "to_x", "to_y"}, {"button", "duration"}),
        "scroll": ({"type", "amount"}, {"x", "y"}),
        "type": ({"type", "text"}, {"method"}),
        "key": ({"type", "key"}, set()),
        "hotkey": ({"type", "keys"}, set()),
        "wait": ({"type", "seconds"}, set()),
        "observe": ({"type"}, set()),
        "finish": ({"type"}, {"reason"}),
    }
    if kind not in schemas:
        _invalid("Unsupported action type", action_type=kind)
    _fields(data, *schemas[kind])
    result = dict(data)
    for field in ("x", "y", "to_x", "to_y"):
        if field in data:
            _coordinate(data[field], field)
    if kind == "scroll":
        if type(data["amount"]) is not int or not -20 <= data["amount"] <= 20 or data["amount"] == 0:
            _invalid("scroll amount must be a nonzero integer in [-20, 20]")
        if ("x" in data) != ("y" in data):
            _invalid("scroll position requires both x and y")
    if "button" in data and (type(data["button"]) is not str or data["button"] not in ("left", "right", "middle")):
        _invalid("button must be left, right or middle")
    if "duration" in data:
        _number(data["duration"], 0, 5, "duration")
    if kind == "wait":
        _number(data["seconds"], 0, 30, "seconds")
    if kind == "type":
        value = data["text"]
        if type(value) is not str or not 1 <= len(value) <= 10000 or "\x00" in value or any(0xD800 <= ord(c) <= 0xDFFF for c in value):
            _invalid("text must contain 1-10000 valid Unicode characters without NUL")
        method = data.get("method", "unicode")
        if type(method) is not str or method not in ("unicode", "keyboard"):
            _invalid("type method must be unicode or keyboard")
        if method == "keyboard" and any(not 0x20 <= ord(character) <= 0x7E for character in value):
            _invalid("keyboard typing accepts printable ASCII characters only (U+0020-U+007E)")
    if kind == "key":
        result["key"] = _key(data["key"])
    if kind == "hotkey":
        if type(data["keys"]) is not list or not 2 <= len(data["keys"]) <= 6:
            _invalid("hotkey keys must contain 2-6 supported key names")
        result["keys"] = [_key(key) for key in data["keys"]]
        if len(set(result["keys"])) != len(result["keys"]):
            _invalid("hotkey keys must not repeat")
    if "reason" in data and (type(data["reason"]) is not str or len(data["reason"]) > 500):
        _invalid("finish reason must be a string of at most 500 characters")
    return result


def validate_request(payload, *, mode="safe", max_actions=None):
    """Validate without executing input or trusting any screen-supplied instructions."""
    _fields(payload, {"protocol", "session_id", "frame_id", "coordinate_space", "actions", "post_observe"}, {"timeout", "risk", "approval_token"})
    if payload["protocol"] != PROTOCOL or type(payload["protocol"]) is not str:
        _invalid("Unsupported protocol")
    validate_session_id(payload["session_id"])
    validate_frame_id(payload["frame_id"])
    if payload["coordinate_space"] != "normalized_1000" or type(payload["coordinate_space"]) is not str:
        _invalid("coordinate_space must be normalized_1000")
    if type(payload["post_observe"]) is not bool:
        _invalid("post_observe must be a boolean")
    if type(payload["actions"]) is not list or not payload["actions"]:
        _invalid("actions must be a nonempty array")
    limit = action_limit(mode, max_actions)
    if len(payload["actions"]) > limit:
        raise U2CError("BATCH_LIMIT", "Action batch exceeds the session limit", limit=limit, received=len(payload["actions"]))
    risk = payload.get("risk", "none")
    if type(risk) is not str or risk not in RISKS:
        _invalid("Unsupported risk classification")
    if "timeout" in payload:
        _number(payload["timeout"], 0.1, 120, "timeout")
    if "approval_token" in payload and (type(payload["approval_token"]) is not str or not re.fullmatch(r"[A-Za-z0-9_-]{20,128}", payload["approval_token"])):
        _invalid("Invalid approval_token")
    actions = [_action(action) for action in payload["actions"]]
    for index, action in enumerate(actions):
        if action["type"] in ("observe", "finish") and index != len(actions) - 1:
            _invalid("observe and finish must be the final action in a batch")
    return {**payload, "risk": risk, "actions": actions}
