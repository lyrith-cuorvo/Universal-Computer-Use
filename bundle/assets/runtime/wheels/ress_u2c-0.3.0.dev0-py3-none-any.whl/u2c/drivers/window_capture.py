"""Isolated worker for a single window-client render."""

import sys

from ..errors import U2CError
from .windows import WINDOW_CAPTURE_ERRORS, WindowsDriver


def main():
    hwnd, pid, left, top, width, height = map(int, sys.argv[1:])
    bounds = {"left": left, "top": top, "width": width, "height": height}
    try:
        image = WindowsDriver()._render_window_pixels(hwnd, bounds, pid)
    except U2CError as exc:
        raise SystemExit(WINDOW_CAPTURE_ERRORS.get(exc.code, 1)) from None
    sys.stdout.buffer.write(image.tobytes())
