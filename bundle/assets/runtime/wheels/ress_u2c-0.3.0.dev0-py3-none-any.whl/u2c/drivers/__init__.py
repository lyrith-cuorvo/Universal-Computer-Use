"""Native platform drivers; importing this package never sends input."""

from .windows import WindowsDriver

__all__ = ["WindowsDriver"]
