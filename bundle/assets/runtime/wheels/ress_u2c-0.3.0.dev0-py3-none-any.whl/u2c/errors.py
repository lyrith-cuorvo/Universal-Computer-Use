"""Machine-readable errors shared by the runtime and CLI."""
from __future__ import annotations


class U2CError(Exception):
    def __init__(self, code: str, message: str, **details):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details

    def as_dict(self):
        return {"code": self.code, "message": self.message, "details": self.details}
