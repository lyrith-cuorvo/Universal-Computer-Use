"""Bounded cleanup of runtime-generated PNG files, never user-selected paths."""
from pathlib import Path
import time
import uuid


def _redirected(path):
    for candidate in (path, *path.parents):
        try:
            if candidate.is_symlink() or getattr(candidate.lstat(), "st_file_attributes", 0) & 0x400:
                return True
        except OSError:
            return True
    return False


def prune_owned_frames(root, session_id, keep=8, max_age=900, preserve=None):
    if str(uuid.UUID(session_id)) != session_id:
        return
    frame_root = Path(root).absolute() / "frames"
    directory = frame_root / session_id
    # Reject symlink/junction redirection; metadata paths are deliberately unused.
    if not directory.is_dir() or _redirected(directory):
        return
    if directory.resolve().parent != frame_root.resolve():
        return
    candidates = []
    for path in directory.glob("*.png"):
        if _redirected(path) or path.resolve().parent != directory.resolve():
            continue
        try:
            if str(uuid.UUID(path.stem)) != path.stem:
                continue
            candidates.append((path.stat().st_mtime, path))
        except (ValueError, OSError):
            continue
    candidates.sort(reverse=True)
    cutoff = time.time() - max_age
    for index, (modified, path) in enumerate(candidates):
        if preserve and path.resolve() == Path(preserve).resolve():
            continue
        if index >= keep or modified < cutoff:
            try:
                path.unlink()
            except OSError:
                pass  # Retention never masks a safety receipt or input cleanup.
