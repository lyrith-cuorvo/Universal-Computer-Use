"""Process-safe local session, screenshot lease and one-use approval storage."""
from __future__ import annotations

from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import secrets
import sqlite3
import time
import uuid

from .errors import U2CError
from .protocol import action_limit, validate_frame_id, validate_session_id


def _redact(value):
    if isinstance(value, dict):
        return {key: "[REDACTED]" if key.lower() in {"text", "typed_text", "clipboard", "approval_token"} else _redact(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_redact(item) for item in value]
    return value


class SessionStore:
    """SQLite transactions serialize claims and approvals across CLI processes.

    A claim permanently consumes its screenshot even if execution fails. Leases
    expire using wall-clock epoch time so unrelated processes share deadlines.
    """

    def __init__(self, root=None):
        if root is None:
            root = os.environ.get("U2C_STATE_DIR")
        if root is None:
            root = Path(os.environ["LOCALAPPDATA"]) / "RESS" / "U2C" if os.environ.get("LOCALAPPDATA") else Path.home() / ".local" / "state" / "u2c"
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.database = self.root / "state.sqlite3"
        db = self._connect()
        try:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY, mode TEXT NOT NULL,
                    frame_ttl REAL NOT NULL, max_actions INTEGER NOT NULL,
                    status TEXT NOT NULL, created_at REAL NOT NULL,
                    updated_at REAL NOT NULL, latest_frame_id TEXT,
                    lease_token TEXT, lease_until REAL
                );
                CREATE TABLE IF NOT EXISTS frames (
                    session_id TEXT NOT NULL, frame_id TEXT NOT NULL,
                    created_at REAL NOT NULL, data TEXT NOT NULL,
                    consumed INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY(session_id, frame_id),
                    FOREIGN KEY(session_id) REFERENCES sessions(session_id)
                );
                CREATE TABLE IF NOT EXISTS approvals (
                    token TEXT PRIMARY KEY, session_id TEXT NOT NULL,
                    request_hash TEXT NOT NULL, reason TEXT NOT NULL,
                    expires_at REAL NOT NULL, consumed INTEGER NOT NULL DEFAULT 0,
                    FOREIGN KEY(session_id) REFERENCES sessions(session_id)
                );
                CREATE TABLE IF NOT EXISTS receipts (
                    receipt_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL, created_at REAL NOT NULL,
                    data TEXT NOT NULL,
                    FOREIGN KEY(session_id) REFERENCES sessions(session_id)
                );
            """)
        finally:
            db.close()
        if os.name != "nt":
            self.root.chmod(0o700)
            self.database.chmod(0o600)

    def _connect(self):
        db = sqlite3.connect(self.database, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=10000")
        return db

    @contextmanager
    def _transaction(self, *, write=True):
        db = self._connect()
        try:
            db.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def _session(db, session_id, *, active=True):
        validate_session_id(session_id)
        row = db.execute("SELECT * FROM sessions WHERE session_id=?", (session_id,)).fetchone()
        if row is None:
            raise U2CError("INVALID_SESSION", "Unknown session_id")
        if active and row["status"] != "active":
            raise U2CError("STOP_REQUESTED", "Session is stopped or finished", status=row["status"])
        return row

    @staticmethod
    def _public(row):
        return {key: row[key] for key in ("session_id", "mode", "frame_ttl", "max_actions", "status", "created_at", "updated_at", "latest_frame_id")}

    def create(self, mode="safe", frame_ttl=30, max_actions=None):
        limit = action_limit(mode, max_actions)
        if type(frame_ttl) not in (int, float) or not 0.1 <= frame_ttl <= 300 or not math.isfinite(frame_ttl):
            raise U2CError("INVALID_REQUEST", "frame_ttl must be between 0.1 and 300 seconds")
        session_id, now = str(uuid.uuid4()), time.time()
        with self._transaction() as db:
            db.execute("INSERT INTO sessions(session_id, mode, frame_ttl, max_actions, status, created_at, updated_at) VALUES(?,?,?,?,'active',?,?)", (session_id, mode, frame_ttl, limit, now, now))
            return self._public(self._session(db, session_id))

    def get(self, session_id):
        with self._transaction() as db:
            return self._public(self._session(db, session_id, active=False))

    def latest_frame_metadata(self, session_id):
        """Read capture scope even when the latest frame is consumed or expired."""
        with self._transaction(write=False) as db:
            session = self._session(db, session_id)
            row = db.execute("SELECT data FROM frames WHERE session_id=? AND frame_id=?",
                             (session_id, session["latest_frame_id"])).fetchone()
            return json.loads(row["data"]) if row else None

    def publish_frame(self, session_id, frame):
        if type(frame) is not dict:
            raise U2CError("INVALID_REQUEST", "frame must be an object")
        frame_id = validate_frame_id(frame.get("frame_id"))
        created_at = frame.get("created_at")
        now = time.time()
        if type(created_at) not in (int, float) or not 0 < created_at <= now + 1 or not math.isfinite(created_at):
            raise U2CError("INVALID_REQUEST", "frame created_at must be an epoch timestamp no later than now")
        value = {**frame, "session_id": session_id}
        serialized = json.dumps(value, allow_nan=False, ensure_ascii=False)
        if len(serialized.encode("utf-8")) > 1024 * 1024:
            raise U2CError("INVALID_REQUEST", "Frame metadata exceeds 1 MiB")
        with self._transaction() as db:
            session = self._session(db, session_id)
            now = time.time()
            if db.execute("SELECT 1 FROM sessions WHERE lease_token IS NOT NULL AND lease_until>? LIMIT 1", (now,)).fetchone():
                raise U2CError("SESSION_BUSY", "Cannot publish a screenshot while a desktop action batch is running")
            try:
                db.execute("INSERT INTO frames(session_id, frame_id, created_at, data) VALUES(?,?,?,?)", (session_id, frame_id, created_at, serialized))
            except sqlite3.IntegrityError:
                raise U2CError("STALE_FRAME", "frame_id has already been published") from None
            db.execute("UPDATE sessions SET latest_frame_id=?, updated_at=? WHERE session_id=?", (frame_id, now, session_id))
            return value

    @staticmethod
    def _frame(db, session, frame_id, now):
        validate_frame_id(frame_id)
        row = db.execute("SELECT * FROM frames WHERE session_id=? AND frame_id=?", (session["session_id"], frame_id)).fetchone()
        if row is None or session["latest_frame_id"] != frame_id or row["consumed"] or now - row["created_at"] > session["frame_ttl"]:
            raise U2CError("STALE_FRAME", "A current, unconsumed screenshot is required; observe again")
        return row

    def frame(self, session_id, frame_id):
        with self._transaction() as db:
            session = self._session(db, session_id)
            return json.loads(self._frame(db, session, frame_id, time.time())["data"])

    def claim(self, session_id, frame_id, timeout=15):
        if type(timeout) not in (int, float) or not 0.1 <= timeout <= 120 or not math.isfinite(timeout):
            raise U2CError("INVALID_REQUEST", "timeout must be between 0.1 and 120 seconds")
        token = secrets.token_urlsafe(32)
        with self._transaction() as db:
            now = time.time()
            session = self._session(db, session_id)
            if db.execute("SELECT 1 FROM sessions WHERE lease_token IS NOT NULL AND lease_until>? LIMIT 1", (now,)).fetchone():
                raise U2CError("SESSION_BUSY", "Another action batch holds the desktop")
            self._frame(db, session, frame_id, now)
            db.execute("UPDATE frames SET consumed=1 WHERE session_id=? AND frame_id=?", (session_id, frame_id))
            db.execute("UPDATE sessions SET lease_token=?, lease_until=?, updated_at=? WHERE session_id=?", (token, now + timeout, now, session_id))
        return token

    def check(self, session_id, token):
        with self._transaction() as db:
            session = self._session(db, session_id)
            if session["lease_token"] != token or session["lease_until"] is None or time.time() >= session["lease_until"]:
                raise U2CError("TIMEOUT", "Action lease has expired or been superseded")

    def release(self, session_id, token, frame=None):
        """Release only the owned lease, optionally publishing its final capture.

        Publishing and releasing share one transaction, so a competing observer
        cannot interleave a newer frame between these operations. A stopped,
        finished, expired or superseded worker cannot publish a screenshot.
        """
        with self._transaction() as db:
            session = self._session(db, session_id, active=False)
            if session["lease_token"] != token:
                return None
            now = time.time()
            published = None
            if frame is not None and session["status"] == "active" and session["lease_until"] is not None and session["lease_until"] > now:
                if type(frame) is not dict:
                    raise U2CError("INVALID_REQUEST", "frame must be an object")
                frame_id = validate_frame_id(frame.get("frame_id"))
                created_at = frame.get("created_at")
                if type(created_at) not in (int, float) or not 0 < created_at <= now + 1 or not math.isfinite(created_at):
                    raise U2CError("INVALID_REQUEST", "frame created_at must be an epoch timestamp no later than now")
                published = {**frame, "session_id": session_id}
                serialized = json.dumps(published, allow_nan=False, ensure_ascii=False)
                if len(serialized.encode("utf-8")) > 1024 * 1024:
                    raise U2CError("INVALID_REQUEST", "Frame metadata exceeds 1 MiB")
                try:
                    db.execute("INSERT INTO frames(session_id, frame_id, created_at, data) VALUES(?,?,?,?)", (session_id, frame_id, created_at, serialized))
                except sqlite3.IntegrityError:
                    raise U2CError("STALE_FRAME", "frame_id has already been published") from None
                db.execute("UPDATE sessions SET latest_frame_id=? WHERE session_id=?", (frame_id, session_id))
            # An expired worker cannot clear a newer worker's lease.
            db.execute("UPDATE sessions SET lease_token=NULL, lease_until=NULL, updated_at=? WHERE session_id=? AND lease_token=?", (now, session_id, token))
            return published

    def stop(self, session_id):
        with self._transaction() as db:
            self._session(db, session_id, active=False)
            db.execute("UPDATE sessions SET status='stopped', updated_at=? WHERE session_id=?", (time.time(), session_id))
            db.execute("UPDATE approvals SET consumed=1 WHERE session_id=?", (session_id,))
            return self._public(self._session(db, session_id, active=False))

    def finish(self, session_id):
        with self._transaction() as db:
            self._session(db, session_id)
            db.execute("UPDATE sessions SET status='finished', updated_at=? WHERE session_id=?", (time.time(), session_id))
            db.execute("UPDATE approvals SET consumed=1 WHERE session_id=?", (session_id,))
            return self._public(self._session(db, session_id, active=False))

    def record(self, session_id, receipt):
        value = json.dumps(_redact(receipt), ensure_ascii=False, allow_nan=False)
        with self._transaction() as db:
            self._session(db, session_id, active=False)
            db.execute("INSERT INTO receipts(session_id, created_at, data) VALUES(?,?,?)", (session_id, time.time(), value))

    def receipts(self, session_id):
        with self._transaction() as db:
            self._session(db, session_id, active=False)
            return [json.loads(row["data"]) for row in db.execute("SELECT data FROM receipts WHERE session_id=? ORDER BY receipt_id", (session_id,))]

    def approve(self, session_id, request_hash, reason):
        """Called only after the CLI receives an explicit interactive confirmation."""
        if type(request_hash) is not str or len(request_hash) != 64 or any(c not in "0123456789abcdef" for c in request_hash):
            raise U2CError("INVALID_REQUEST", "request_hash must be a SHA-256 digest")
        if type(reason) is not str or not reason.strip() or len(reason) > 500:
            raise U2CError("INVALID_REQUEST", "Approval requires a reason of 1-500 characters")
        token, expires_at = secrets.token_urlsafe(32), time.time() + 120
        with self._transaction() as db:
            self._session(db, session_id)
            db.execute("INSERT INTO approvals(token, session_id, request_hash, reason, expires_at) VALUES(?,?,?,?,?)", (token, session_id, request_hash, reason, expires_at))
        return {"approval_token": token, "request_hash": request_hash, "expires_at": expires_at}

    def consume_approval(self, session_id, token, request_hash):
        with self._transaction() as db:
            self._session(db, session_id)
            row = db.execute("SELECT * FROM approvals WHERE token=? AND session_id=?", (token, session_id)).fetchone()
            if row is None or row["consumed"] or row["expires_at"] <= time.time() or not secrets.compare_digest(row["request_hash"], request_hash):
                raise U2CError("APPROVAL_REQUIRED", "Approval is absent, expired, already used or bound to a different request")
            db.execute("UPDATE approvals SET consumed=1 WHERE token=?", (token,))
