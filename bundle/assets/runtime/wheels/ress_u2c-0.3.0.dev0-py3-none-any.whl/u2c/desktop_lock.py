"""Nonblocking desktop-wide exclusion, independent of a U2C state directory.

Windows uses a session-local kernel mutex, never an application lock file.
WAIT_ABANDONED grants ownership; we release it and reject that operation so the
caller can explicitly emergency-stop, reobserve, and recover. Windows destroys
a named mutex after its last handle closes, so abandonment cannot be detected
after *all* processes holding handles have exited. This is not an OS audit log.

The POSIX fallback is for portable protocol tests. Its persistent file is only
a rendezvous point for flock; existence is never interpreted as ownership.
"""
from __future__ import annotations

import ctypes
import errno
import os
import stat
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path

from .errors import U2CError

MUTEX_NAME = r"Local\RESS.U2C.Desktop.v0"
WAIT_OBJECT_0 = 0
WAIT_ABANDONED = 0x80
WAIT_TIMEOUT = 0x102
WAIT_FAILED = 0xFFFFFFFF


def _kernel32():
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    handle = ctypes.c_void_p
    dword = ctypes.c_uint32
    boolean = ctypes.c_int32
    api.CreateMutexW.argtypes = [ctypes.c_void_p, boolean, ctypes.c_wchar_p]
    api.CreateMutexW.restype = handle
    api.WaitForSingleObject.argtypes = [handle, dword]
    api.WaitForSingleObject.restype = dword
    api.ReleaseMutex.argtypes = [handle]
    api.ReleaseMutex.restype = boolean
    api.CloseHandle.argtypes = [handle]
    api.CloseHandle.restype = boolean
    return api


def _last_error():
    return ctypes.get_last_error() if hasattr(ctypes, "get_last_error") else 0


@contextmanager
def _windows_lock():
    api = _kernel32()
    handle = api.CreateMutexW(None, False, MUTEX_NAME)
    if not handle:
        raise U2CError("PERMISSION_DENIED", "Could not open the session-wide desktop mutex",
                       winerror=_last_error())
    owned = False
    try:
        outcome = int(api.WaitForSingleObject(handle, 0))
        if outcome == WAIT_TIMEOUT:
            raise U2CError("SESSION_BUSY", "Another U2C process owns this interactive desktop")
        if outcome == WAIT_ABANDONED:
            owned = True
            raise U2CError("INPUT_RECOVERY_REQUIRED", "A desktop owner terminated unexpectedly; explicitly stop and reobserve before input",
                           recovery="u2c stop --session SESSION_ID, then u2c observe")
        if outcome != WAIT_OBJECT_0:
            raise U2CError("PERMISSION_DENIED", "Could not acquire the session-wide desktop mutex",
                           wait_result=outcome, winerror=_last_error())
        owned = True
        yield
    finally:
        release_error = None
        if owned and not api.ReleaseMutex(handle):
            release_error = _last_error()
        closed = bool(api.CloseHandle(handle))
        if release_error is not None:
            raise U2CError("PERMISSION_DENIED", "Could not release the desktop mutex", winerror=release_error)
        if not closed:
            raise U2CError("PERMISSION_DENIED", "Could not close the desktop mutex handle", winerror=_last_error())


def _posix_lock_path():
    # A user-specific name avoids unrelated accounts sharing fallback ownership.
    uid = os.getuid() if hasattr(os, "getuid") else "unknown-user"
    return Path(tempfile.gettempdir()) / f"ress-u2c-desktop-v0-{uid}.lock"


@contextmanager
def _posix_lock():
    try:
        import fcntl
    except ImportError as exc:
        raise U2CError("PERMISSION_DENIED", "This platform has no supported process mutex") from exc
    descriptor = None
    owned = False
    try:
        try:
            flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(_posix_lock_path(), flags, 0o600)
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode) or (hasattr(os, "getuid") and info.st_uid != os.getuid()):
                raise U2CError("PERMISSION_DENIED", "Desktop mutex rendezvous is not a regular file owned by this user")
        except OSError as exc:
            raise U2CError("PERMISSION_DENIED", "Could not open the portable desktop test lock",
                           errno=exc.errno) from exc
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            if exc.errno in (errno.EAGAIN, errno.EACCES):
                raise U2CError("SESSION_BUSY", "Another U2C process owns this desktop test lock") from exc
            raise U2CError("PERMISSION_DENIED", "Could not acquire the portable desktop test lock",
                           errno=exc.errno) from exc
        owned = True
        yield
    finally:
        if descriptor is not None:
            try:
                if owned:
                    fcntl.flock(descriptor, fcntl.LOCK_UN)
            finally:
                os.close(descriptor)


@contextmanager
def desktop_lock():
    """Hold nonblocking process exclusion over a complete observe or act call.

    Contention raises SESSION_BUSY without waiting. Acquisition and release must
    occur on the same thread. Windows mutexes are naturally reentrant on that
    thread; callers should wrap each public operation only once for portability.
    No desktop or window is inspected, switched, or focused by this function.
    """
    lock = _windows_lock if sys.platform == "win32" else _posix_lock
    with lock():
        yield
