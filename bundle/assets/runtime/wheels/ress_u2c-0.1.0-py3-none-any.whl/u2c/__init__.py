"""RESS U2C: local, screenshot-grounded computer use."""
__version__ = "0.1.0"

